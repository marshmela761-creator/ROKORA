# ROKORA Android — prototype 0.1.0

Native Android starter project for ROKORA. It is an installable Android app project (not a browser page).

## Build APK
1. Install Android Studio on a computer.
2. Open this folder (`ROKORA-Android`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 when prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to the Infinix GT 30 and install it. Android may ask to allow installs from that file manager.

Package: `com.rokora.app`  
Minimum Android: 6.0 (API 23)  
Target SDK: 35

## Current prototype scope
- Native Android interface and bottom navigation
- Home screen and sample Places cards
- Local avatar color selection saved on the device
- Catalog, friends and profile placeholder screens
- Rokuxx balance display (currently 0)

Not implemented yet: real accounts/authentication, cloud sync, live chat, multiplayer game servers, user-generated Place runtime, payments, or actual Rokuxx purchases. The displayed Places are demos, not playable Roblox experiences. Do not collect payment or credentials in this prototype.
