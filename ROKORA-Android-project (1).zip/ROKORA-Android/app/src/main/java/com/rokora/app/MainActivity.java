package com.rokora.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,16,24), panel = Color.rgb(29,29,43), purple = Color.rgb(128,87,255), muted = Color.rgb(170,169,190);
    private LinearLayout root, content, nav;
    private SharedPreferences prefs;
    private String current = "Главная";
    private int avatarColor;
    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences("rokora",MODE_PRIVATE); avatarColor=prefs.getInt("avatar",Color.rgb(255,190,145)); show("Главная"); }
    private GradientDrawable shape(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v,int n){v.setPadding(n,n,n,n);}
    private void show(String page){ current=page; root=column(); root.setBackgroundColor(bg); setContentView(root);
        LinearLayout header=row(); header.setPadding(18,18,18,14); TextView logo=text("ROKORA",23,Color.WHITE,true); header.addView(logo,new LinearLayout.LayoutParams(0,-2,1)); TextView coins=text("🪙  0 Rokuxx",14,Color.rgb(255,210,100),true); header.addView(coins); root.addView(header);
        ScrollView scroll=new ScrollView(this); content=column(); content.setPadding(16,8,16,20); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(page.equals("Главная")) home(); else if(page.equals("Аватар")) avatar(); else if(page.equals("Каталог")) catalog(); else if(page.equals("Друзья")) friends(); else if(page.equals("Профиль")) profile(); else places();
        nav=row(); nav.setBackgroundColor(Color.rgb(23,23,34)); String[] names={"Главная","Places","Аватар","Каталог","Друзья","Профиль"}; String[] icons={"⌂","▣","☺","◇","♧","●"};
        for(int i=0;i<names.length;i++){ final String name=names[i]; LinearLayout item=column(); item.setGravity(Gravity.CENTER); TextView icon=text(icons[i],19,name.equals(page)?Color.WHITE:muted,true); TextView label=text(names[i],10,name.equals(page)?Color.WHITE:muted,false); item.addView(icon); item.addView(label); item.setPadding(0,10,0,9); item.setOnClickListener(v->show(name)); nav.addView(item,new LinearLayout.LayoutParams(0,-2,1)); } root.addView(nav);
    }
    private void heading(String s){ TextView t=text(s,22,Color.WHITE,true); t.setPadding(0,12,0,12); content.addView(t); }
    private void card(String title,String subtitle,String emoji){ LinearLayout c=column(); c.setPadding(16,14,16,14); c.setBackground(shape(panel,22)); TextView e=text(emoji,30,Color.WHITE,true); c.addView(e); TextView h=text(title,17,Color.WHITE,true); h.setPadding(0,7,0,3); c.addView(h); c.addView(text(subtitle,13,muted,false)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; content.addView(c,lp); }
    private void home(){ TextView welcome=text("Твой игровой мир начинается здесь",24,Color.WHITE,true); welcome.setPadding(0,14,0,8); content.addView(welcome); content.addView(text("Играй • Создавай • Общайся",14,muted,false)); heading("Популярные Places"); card("Obby: Радужная башня","Полоса препятствий · Демоверсия","🌈"); card("Город ROKORA","Исследуй небольшой игровой мир · Скоро","🏙️"); card("Pet World","Знакомься с виртуальными питомцами · Скоро","🐾"); }
    private void places(){ heading("Places"); card("Obby: Радужная башня","Демонстрационная карточка мира. Подключение настоящих игровых серверов будет следующим этапом.","🌈"); card("Город ROKORA","Игровой мир в разработке","🏙️"); }
    private void avatar(){ heading("Мой аватар"); TextView preview=text("●",100,avatarColor,true); preview.setGravity(Gravity.CENTER); preview.setBackground(shape(panel,28)); content.addView(preview,new LinearLayout.LayoutParams(-1,220)); heading("Цвет персонажа"); int[] colors={Color.rgb(255,190,145),Color.rgb(235,190,255),Color.rgb(145,205,255),Color.rgb(160,225,175),Color.rgb(245,215,125)}; LinearLayout r=row(); for(int c:colors){ View swatch=new View(this); swatch.setBackground(shape(c,50)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,52,1); p.setMargins(5,5,5,5); r.addView(swatch,p); swatch.setOnClickListener(v->{avatarColor=c;prefs.edit().putInt("avatar",c).apply();show("Аватар");}); } content.addView(r); content.addView(text("Выбери цвет, чтобы сохранить его на устройстве.",13,muted,false)); }
    private void catalog(){ heading("Каталог"); card("Одежда","Предметы одежды появятся позже","👕"); card("Лица","Выбор выражений персонажа","😀"); card("Аксессуары","Украшения и предметы","🎩"); }
    private void friends(){ heading("Друзья"); card("Твои друзья","Список друзей и приглашения появятся после подключения аккаунтов и сервера.","👥"); }
    private void profile(){ heading("ROKORA ID"); card("Гость","Локальный демонстрационный профиль","🪪"); card("Баланс","0 Rokuxx","🪙"); card("Аккаунт","Регистрация и синхронизация между устройствами будут добавлены с серверной частью.","🔐"); }
}
